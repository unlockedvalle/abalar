#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  ABALAR EXPLOITS — Desinstalador v1.2
#  Debian 11 Bullseye / Debian 12 Bookworm
# ═══════════════════════════════════════════════════════════

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'
WHITE='\033[1;37m'; DIM='\033[2m'; RESET='\033[0m'

clear
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}║${WHITE}     ABALAR EXPLOITS — Desinstalador v1.2            ${CYAN}║${RESET}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR]${RESET} Necesita permisos de root: ${WHITE}sudo bash desinstalar.sh${RESET}"
    exit 1
fi

echo -e "${CYAN}[1/3]${RESET} Eliminando archivos de la app..."
rm -rf /opt/abalar-exploits/
echo -e "       ${GREEN}OK${RESET} /opt/abalar-exploits/ eliminado"

echo -e "${CYAN}[2/3]${RESET} Eliminando lanzador..."
rm -f /usr/local/bin/abalar-exploits
echo -e "       ${GREEN}OK${RESET} Comando eliminado"

echo -e "${CYAN}[3/3]${RESET} Eliminando accesos directos..."
rm -f /usr/share/applications/abalar-exploits.desktop
update-desktop-database /usr/share/applications/ 2>/dev/null || true

REAL_USER="${SUDO_USER:-}"
[ -z "$REAL_USER" ] || [ "$REAL_USER" = "root" ] && \
    REAL_USER=$(who | awk '{print $1}' | grep -v root | head -1)
if [ -n "$REAL_USER" ]; then
    REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6 2>/dev/null || echo "/home/$REAL_USER")
    for DIR in "Escritorio" "Desktop" "escritorio" "desktop"; do
        rm -f "$REAL_HOME/$DIR/abalar-exploits.desktop" 2>/dev/null || true
    done
fi
echo -e "       ${GREEN}OK${RESET} Accesos directos eliminados"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}║${GREEN}   ✓  ABALAR EXPLOITS desinstalado correctamente     ${CYAN}║${RESET}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""
