document.getElementById('launchBtn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: injectInternalWidget
    });
  });
  window.close();
});

function injectInternalWidget() {
  if (document.getElementById('abalar-overlay-container')) return;

  const container = document.createElement('div');
  container.id = 'abalar-overlay-container';
  container.innerHTML = `
    <input type="file" id="abalar-file-input" accept="application/pdf" style="display: none;">

    <!-- Ventana flotante principal con soporte de transición suave -->
    <div id="abalar-floating-box" style="
      position: fixed;
      bottom: 25px;
      right: 25px;
      width: 440px;
      height: 520px;
      background: white;
      border: none;
      border-radius: 12px;
      box-shadow: 0 12px 35px rgba(0,0,0,0.35);
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      resize: both;
      overflow: hidden;
      min-width: 280px;
      min-height: 280px;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      transform-origin: bottom right;
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease;
      opacity: 1;
    ">
      <!-- Cabecera -->
      <div id="abalar-header" style="
        background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%);
        color: white;
        padding: 10px 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: move;
        user-select: none;
      ">
        <div style="display: flex; flex-direction: column; overflow: hidden;">
          <span id="abalar-title" style="font-weight: 700; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px;">ABA-EXP PDF in Pip</span>
          <span style="font-size: 9px; color: #bbdefb; margin-top: 1px; letter-spacing: 0.3px;">Hecho por Abalar Exploits</span>
        </div>
        <div style="display: flex; gap: 8px; align-items: center;">
          <button id="abalar-minimize" title="Minimizar" style="
            background: rgba(255,255,255,0.15); border: none; color: white; width: 26px; height: 26px;
            border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center;
            transition: background 0.2s;
          ">
            <svg width="12" height="2" viewBox="0 0 12 2" fill="none"><path d="M0 1H12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          </button>
          <button id="abalar-close" title="Cerrar" style="
            background: rgba(255,255,255,0.15); border: none; color: white; width: 26px; height: 26px;
            border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center;
            transition: background 0.2s;
          ">
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M1 1L9 9M9 1L1 9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          </button>
        </div>
      </div>

      <!-- Cuerpo central -->
      <div id="abalar-body" style="flex: 1; display: flex; justify-content: center; align-items: center; background: #f8fafc;">
        <button id="abalar-select-btn" style="
          background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%);
          color: white;
          border: none;
          padding: 12px 22px;
          border-radius: 8px;
          font-weight: 600;
          cursor: pointer;
          font-size: 13px;
          box-shadow: 0 4px 12px rgba(13,71,161,0.25);
          transition: transform 0.2s;
        ">📁 Seleccionar Archivo PDF</button>
      </div>
    </div>

    <!-- Burbuja flotante con animación de aparición -->
    <div id="abalar-bubble" title="Restaurar Visor PDF" style="
      position: fixed;
      bottom: 25px;
      right: 25px;
      width: 54px;
      height: 54px;
      background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%);
      color: white;
      border-radius: 50%;
      box-shadow: 0 6px 20px rgba(13, 71, 161, 0.4);
      z-index: 2147483647;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      border: 2px solid white;
      user-select: none;
      transform: scale(0);
      opacity: 0;
      pointer-events: none;
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease, box-shadow 0.2s;
    " onmouseover="this.style.transform+=' scale(1.08)';" onmouseout="this.style.transform=this.style.transform.replace(' scale(1.08)','');">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
      </svg>
    </div>
  `;

  document.body.appendChild(container);

  const fileInput = document.getElementById('abalar-file-input');
  const selectBtn = document.getElementById('abalar-select-btn');
  const floatingBox = document.getElementById('abalar-floating-box');
  const header = document.getElementById('abalar-header');
  const closeBtn = document.getElementById('abalar-close');
  const minimizeBtn = document.getElementById('abalar-minimize');
  const bubbleBtn = document.getElementById('abalar-bubble');
  const titleSpan = document.getElementById('abalar-title');
  const bodyContainer = document.getElementById('abalar-body');

  selectBtn.onclick = () => fileInput.click();
  closeBtn.onclick = () => container.remove();

  // Animación suave al minimizar
  minimizeBtn.onclick = () => {
    floatingBox.style.transform = 'scale(0)';
    floatingBox.style.opacity = '0';
    setTimeout(() => {
      floatingBox.style.display = 'none';
      bubbleBtn.style.display = 'flex';
      bubbleBtn.style.pointerEvents = 'auto';
      bubbleBtn.style.transform = 'scale(1)';
      bubbleBtn.style.opacity = '1';
    }, 300);
  };

  // Animación suave al restaurar
  bubbleBtn.onclick = () => {
    bubbleBtn.style.transform = 'scale(0)';
    bubbleBtn.style.opacity = '0';
    bubbleBtn.style.pointerEvents = 'none';
    setTimeout(() => {
      bubbleBtn.style.display = 'none';
      floatingBox.style.display = 'flex';
      // Forzar reflow
      floatingBox.offsetHeight;
      floatingBox.style.transform = 'scale(1)';
      floatingBox.style.opacity = '1';
    }, 300);
  };

  fileInput.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const fileURL = URL.createObjectURL(file);
    titleSpan.innerText = file.name;

    bodyContainer.innerHTML = `
      <embed src="${fileURL}" type="application/pdf" style="width: 100%; height: 100%; border: none;">
    `;
  };

  // Movimiento fluido de arrastre (Drag & Drop)
  let isDragging = false;
  let startX, startY, initialLeft, initialTop;

  header.onmousedown = (e) => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;

    const rect = floatingBox.getBoundingClientRect();
    floatingBox.style.bottom = 'auto';
    floatingBox.style.right = 'auto';
    floatingBox.style.left = rect.left + 'px';
    floatingBox.style.top = rect.top + 'px';

    initialLeft = rect.left;
    initialTop = rect.top;

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };

  function onMouseMove(e) {
    if (!isDragging) return;
    floatingBox.style.left = (initialLeft + (e.clientX - startX)) + 'px';
    floatingBox.style.top = (initialTop + (e.clientY - startY)) + 'px';
  }

  function onMouseUp() {
    isDragging = false;
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
  }
}
