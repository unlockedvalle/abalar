#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  ABALAR EXPLOITS — Instalador v1.1 (WebKit edition)
#  Debian 11 Bullseye / Debian 12 Bookworm
# ═══════════════════════════════════════════════════════════

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; WHITE='\033[1;37m'; DIM='\033[2m'; RESET='\033[0m'

clear
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}║${WHITE}     ABALAR EXPLOITS — Instalador v1.1 WebKit       ${CYAN}║${RESET}"
echo -e "${CYAN}║${DIM}     Debian 11 Bullseye / Debian 12 Bookworm         ${CYAN}║${RESET}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR]${RESET} Necesita permisos de root: ${WHITE}sudo bash instalar.sh${RESET}"
    exit 1
fi

. /etc/os-release 2>/dev/null || true
DEBIAN_VER="${VERSION_ID:-0}"
echo -e "${DIM}Sistema: ${WHITE}${PRETTY_NAME:-Linux}${RESET}"

REAL_USER="${SUDO_USER:-}"
if [ -z "$REAL_USER" ] || [ "$REAL_USER" = "root" ]; then
    REAL_USER=$(who | awk '{print $1}' | grep -v root | head -1)
fi
[ -z "$REAL_USER" ] && REAL_USER="usuario"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6 2>/dev/null || echo "/home/$REAL_USER")
echo -e "${DIM}Usuario: ${WHITE}$REAL_USER${RESET}"
echo ""

# ── [1/5] Dependencias ─────────────────────────────────────
echo -e "${CYAN}[1/5]${RESET} Instalando dependencias..."
apt-get update -qq 2>/dev/null

# WebKit2GTK — versiones disponibles por Debian
if dpkg --compare-versions "$DEBIAN_VER" ge 12 2>/dev/null; then
    # Debian 12: webkit2gtk 4.1
    WEBKIT_PKG="gir1.2-webkit2-4.1 libwebkit2gtk-4.1-0"
    GTK_PKG="python3-gi gir1.2-gtk-4.0"
    echo -e "       WebKit2GTK 4.1 + GTK4 ${GREEN}(Debian 12)${RESET}"
else
    # Debian 11: webkit2gtk 4.0 o 4.1
    WEBKIT_PKG="gir1.2-webkit2-4.1 libwebkit2gtk-4.1-0"
    GTK_PKG="python3-gi gir1.2-gtk-3.0"
    # Fallback a 4.0 si 4.1 no existe
    apt-cache show gir1.2-webkit2-4.1 &>/dev/null || \
        WEBKIT_PKG="gir1.2-webkit2-4.0 libwebkit2gtk-4.0-37"
    echo -e "       WebKit2GTK + GTK3 ${YELLOW}(Debian 11)${RESET}"
fi

apt-get install -y $WEBKIT_PKG $GTK_PKG python3 wget xdg-utils policykit-1 2>/dev/null \
    | grep -E "^(Setting up|Configurando)" || true
echo -e "       ${GREEN}OK${RESET} Dependencias instaladas"

# ── [2/5] Copiar archivos ───────────────────────────────────
echo -e "${CYAN}[2/5]${RESET} Instalando archivos..."
APP_DIR="/opt/abalar-exploits"
mkdir -p "$APP_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cp "$SCRIPT_DIR/abalar_exploits.py" "$APP_DIR/"
cp "$SCRIPT_DIR/index_app.html"     "$APP_DIR/"
[ -f "$SCRIPT_DIR/logo.png" ] && cp "$SCRIPT_DIR/logo.png" "$APP_DIR/"
chmod 755  "$APP_DIR"
chmod 755  "$APP_DIR/abalar_exploits.py"
chmod 644  "$APP_DIR/index_app.html"
[ -f "$APP_DIR/logo.png" ] && chmod 644 "$APP_DIR/logo.png"
echo -e "       ${GREEN}OK${RESET} Copiado a ${WHITE}/opt/abalar-exploits/${RESET}"

# ── [3/5] Lanzador ─────────────────────────────────────────
echo -e "${CYAN}[3/5]${RESET} Creando lanzador..."
cat > /usr/local/bin/abalar-exploits << 'LAUNCHER'
#!/bin/bash
export DISPLAY="${DISPLAY:-:0}"
if [ "$(id -u)" = "0" ]; then
    RU="${SUDO_USER:-}"
    [ -z "$RU" ] || [ "$RU" = "root" ] && \
        RU=$(who | awk '{print $1}' | grep -v root | head -1)
    if [ -n "$RU" ]; then
        XA="$(getent passwd "$RU" | cut -d: -f6)/.Xauthority"
        [ -f "$XA" ] && export XAUTHORITY="$XA"
        xhost +SI:localuser:root 2>/dev/null || true
    fi
fi
exec python3 /opt/abalar-exploits/abalar_exploits.py "$@"
LAUNCHER
chmod 755 /usr/local/bin/abalar-exploits
echo -e "       ${GREEN}OK${RESET} Comando ${WHITE}abalar-exploits${RESET} listo"

# ── [4/5] Acceso directo ────────────────────────────────────
echo -e "${CYAN}[4/5]${RESET} Creando accesos directos..."
if [ -f "/opt/abalar-exploits/logo.png" ]; then
    ICON_PATH="/opt/abalar-exploits/logo.png"
else
    ICON_PATH="applications-internet"
fi

DESKTOP="[Desktop Entry]
Name=ABALAR EXPLOITS
GenericName=Guias Tecnicas Abalar
Comment=Guias y exploits para Abalinux y Abalar
Exec=abalar-exploits
Icon=$ICON_PATH
Terminal=false
Type=Application
Categories=Utility;System;
StartupNotify=true
"
echo "$DESKTOP" > /usr/share/applications/abalar-exploits.desktop
chmod 644 /usr/share/applications/abalar-exploits.desktop
update-desktop-database /usr/share/applications/ 2>/dev/null || true

for DIR in "Escritorio" "Desktop" "escritorio" "desktop"; do
    TARGET="$REAL_HOME/$DIR"
    if [ -d "$TARGET" ]; then
        echo "$DESKTOP" > "$TARGET/abalar-exploits.desktop"
        chmod +x "$TARGET/abalar-exploits.desktop"
        chown "$REAL_USER:$REAL_USER" "$TARGET/abalar-exploits.desktop" 2>/dev/null || true
        echo -e "       ${GREEN}OK${RESET} Icono en ${WHITE}$TARGET${RESET}"
        break
    fi
done

# ── [5/5] Verificar ─────────────────────────────────────────
echo -e "${CYAN}[5/5]${RESET} Verificando WebKit..."
if python3 -c "
import gi
for v in ['4.1','4.0']:
    try: gi.require_version('WebKit2',v); from gi.repository import WebKit2; print('OK '+v); break
    except: pass
" 2>/dev/null | grep -q "OK"; then
    echo -e "       ${GREEN}OK${RESET} WebKit2GTK funciona correctamente"
else
    echo -e "       ${YELLOW}AVISO${RESET} No se pudo verificar WebKit (puede ser normal sin display)"
fi

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}║${GREEN}   ✓  ABALAR EXPLOITS instalado correctamente        ${CYAN}║${RESET}"
echo -e "${CYAN}╠══════════════════════════════════════════════════════╣${RESET}"
echo -e "${CYAN}║                                                      ║${RESET}"
echo -e "${CYAN}║  ${WHITE}Lanzar:  ${DIM}abalar-exploits${RESET}                          ${CYAN}║${RESET}"
echo -e "${CYAN}║  ${WHITE}O desde el icono del escritorio / menu de apps${RESET}    ${CYAN}║${RESET}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""
